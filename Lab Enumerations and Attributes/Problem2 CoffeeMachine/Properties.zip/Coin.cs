﻿public enum Coin
{
    One,
    Two,
    Five =5,
    Ten = 10,
    Twenty = 20,
    Fifty = 50,

}

