﻿public interface ICallable
{
    string Call(string number);
}

