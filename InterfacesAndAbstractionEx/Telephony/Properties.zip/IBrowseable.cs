﻿public interface IBrowseable
{
    string Browse(string url);
}

