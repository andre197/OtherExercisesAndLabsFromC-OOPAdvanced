﻿public interface IAge : IName
{
    int Age { get; }
}

