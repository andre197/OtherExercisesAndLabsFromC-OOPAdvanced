﻿public interface IName
{
    string Name { get; }

}

