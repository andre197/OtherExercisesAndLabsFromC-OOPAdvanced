﻿public interface ICar
{
    string PushBreaks();
    string PushGas();
}

